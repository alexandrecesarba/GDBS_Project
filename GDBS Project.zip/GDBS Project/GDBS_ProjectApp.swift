//
//  GDBS_ProjectApp.swift
//  GDBS Project
//
//  Created by Alexandre César Brandão de Andrade on 13/01/25.
//

import SwiftUI

@main
struct GDBS_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
