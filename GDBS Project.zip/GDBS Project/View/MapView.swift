import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
    let regionData: [String: Region]

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        GeoJSONLoader.loadGeoJSON(into: mapView, with: regionData)
        return mapView
    }

    func updateUIView(_ uiView: MKMapView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(regionData: regionData)
    }
}
